RDP - FREE

© Zaky


+ RDP Windows Gratis 6 Jam

+ Buat RDP Windows 10 Ram 7GB 2 Core Cpu Dengan Github:

+ Tekan Tombol Fork untuk membuat RDP (Bagi Pengguna Android/HP Disilahkan Pake Mode Desktop).

+ kunjungi https://dashboard.ngrok.com untuk mendapatkan NGROK_AUTH_TOKEN

+ Di Dalam Repo ini Pergi ke Settings> Secrets> New repository secret

+ isi Nama: Masukan NGROK_AUTH_TOKEN

+ isi Value: Kunjungi https://dashboard.ngrok.com/auth/your-authtoken Copy Dan Paste di dalam value

+ Tekan Add secret

+ Pergi Ke Action <Klik Select workflow< Pilih Zaky,Pencet Run workflow

+ Refresh Web/halaman dan masuk ke Zaky> klik build

+ *Tunggu 1-5 menit*

+ Tekan Tombol panah menghadap ke bawah Yg bertuliskan (Connect RDP.) Untuk Mendapatkan IP, User, Password.

+  ```Peringatan jika Rdp close silahkan klik Action<Pilih Zaky<Klik build, Klik titik tiga klik run-rensjob dan jalan kan lagi Rdp nya```


